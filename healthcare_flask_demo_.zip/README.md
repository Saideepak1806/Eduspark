# Healthcare Flask Demo

This is a ready-to-run demo for Hackathon.

## Run:
```bash
pip install -r requirements.txt
python app.py
```
Patients: Rajeev Kumar, Anitha Sharma, Suresh Patel